Table of contents
m200.inp:H*(10) taken from EXPACS (https:/phits.jaea.go.jp/expacs/)
m201.inp:Effective dose based on ICRP60 (AP irradiation) taken from ICRP74 & JAERI-1345
m202.inp:Effective dose based on ICRP103 (AP irradiation) taken from ICRP116 & ICRP123
m203.inp:Effective dose based on ICRP103 (ISO irradiation) taken from ICRP116 & ICRP123
m204.inp:New operational quantity H. (Maximum effective dose among the all irradiation conditions based on ICRU95
m210.inp:Sex-averaged effective dose equivalent (ISO irradiation) taken from ICRP123
m211.inp:Effective dose equivalent for male (ISO irradiation) taken from ICRP123
m212.inp:Effective dose equivalent for female (ISO irradiation) taken from ICRP123
m213.inp:Dose equivalent for male red-bone marrow (ISO irradiation) taken from ICRP123
m214.inp:Dose equivalent for female red-bone marrow (ISO irradiation) taken from ICRP123
m215.inp:Dose equivalent for male skin (ISO irradiation) taken from ICRP123
m216.inp:Dose equivalent for female skin (ISO irradiation) taken from ICRP123
m299.inp:Soft error rate (FIT/Mbit)/(/cm2/s) based on Abe & Watanabe, IEEE Trans Nucl. Sci. 61, 3519 (2014)
