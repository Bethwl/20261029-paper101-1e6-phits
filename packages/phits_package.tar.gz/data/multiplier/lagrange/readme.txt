Comparison between results interpolated with lagrange=2 and =4 for the dose conversion coefficients.
